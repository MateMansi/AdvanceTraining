package medicine;

interface MedicineInfo {

	
 void displayLabel();
		 
	class Tablet implements MedicineInfo{
		 
	public void displayLabel(){
		System.out.println("Consumption as directed by the physician");
		}
	}
	class Syrup implements  MedicineInfo{
		public void displayLabel(){
		System.out.println("Store it in dry place");
		}
		}
	class Ointment implements MedicineInfo{
		public void displayLabel(){
		System.out.println("for external use only");
	}
	}
}

