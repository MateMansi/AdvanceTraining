import java.util.Iterator;
import java.util.Scanner;
import java.util.HashMap;

public class PhoneBook {

	public static String help_msg= "Press: A: Add contact \n S: Search \n Q:A Exit :";
	public static void main(String[] args) {
		 HashMap<String, Integer> map = new HashMap<>();
		
		 map.put("John Doe",785236);
	        map.put("Manny Mat", 879656);
	        map.put("jerry tom", 524120);
	        System.out.println(map);
	        
		
		
		System.out.println("\n\n Welcome to My PhoneBook \n\n");
		Scanner sc=new Scanner(System.in);
		for (;;) {
			System.out.print("[Main Menu] "+help_msg+"\n:");
			String command=sc.nextLine().trim();
			
			
			if (command.equalsIgnoreCase("A")) {
				System.out.println("Enter the contact to add ");
				String contact=sc.nextLine();
				 map.put(contact, null);
			        System.out.println(map);
				
			}
			else if (command.equalsIgnoreCase("S")) {
				System.out.println("Enter the  name you are searching for :\n:");
				String search=sc.nextLine();
				
				
			}
			else if (command.equalsIgnoreCase("Q")) {
				System.out.println("Good Bye User...");
				System.exit(0);
			}
			else {
				System.out.println("Unknown command ! Try Again \n:");
			}
		}
	}
}
