package EmployeeLinkedList;
import java.awt.List;
import java.util.LinkedList;
import java.util.Vector;

class Employee {
	
	 
		int eno;  
		String ename,eaddress;  
		  
		public Employee(int eno, String ename, String eaddress) {  
		    this.eno = eno;  
		    this.ename = ename;  
		    this.eaddress = eaddress;  
		     
		}  
		}  
		public class EmployeeList {  
		public static void main(String[] args) {  
		    
			LinkedList<Employee> list=new LinkedList<Employee>();  
		 
		    Employee e1=new  Employee(101,"Mansi Mate","Pune");  
		    Employee e2=new Employee(102,"Nick John","Mumbai");  
		    Employee e3=new  Employee(103,"Sona patil","Delhi");  
		      
		    list.add(e1);  
		    list.add(e2);  
		    list.add(e3);  
		     
		    for( Employee e:list){  
		    System.out.println(e.eno+" "+e.ename+" "+e.eaddress);  
		    }  
		}
		}