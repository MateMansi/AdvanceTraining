

	import java.util.Scanner;


	public class Rectangle1 {

		
	   int length=1; 
	    int breadth=1; 
	    int area; 
	    int perimeter;

	    
	    public int getLength() {
			return length;
		}

		public void setLength(int length) {
			this.length = length;
		}

		public int getBreadth() {
			return breadth;
		}

		public void setBreadth(int breadth) {
			this.breadth = breadth;
		}

		void calculate() {
	        area = length * breadth;
	        perimeter = 2 * (length + breadth);
	    }

	    void display() {
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Perimeter of Rectangle = " + perimeter);
	    }

	    public static void main(String args[]) {
	        Rectangle1 obj = new Rectangle1();
	      
	        obj.calculate();
	        obj.display();
	    }
	}




