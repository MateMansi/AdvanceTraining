
	import java.util.Scanner;

	public class Rectangle {
	    int length; 
	    int breadth; 
	    int area;
	     
	  
	    Rectangle(int len, int bre){  
	         length = len;  
	         breadth = bre;  
	          
	        } 
	    void calculate() {
	        area = length * breadth;
	     
	    }

	    void display() {
	        System.out.println("Area of Rectangle = " + area);
	       
	    }

	    public static void main(String args[]) {
	        Rectangle obj1 = new Rectangle(20,10);
	       Rectangle obj2 = new Rectangle(50,25);
	        
	        
	        obj1.calculate();
	        obj1.display();
	        obj2.calculate();
	        obj2.display();
	    }

}
