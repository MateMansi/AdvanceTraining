
import java.util.*; 
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class Demo implements java.io.Serializable 
{ 
	private static final long serialVersionUID = 1L;
	
	 int a; 
     String b; 
     int c; 
     String d; 
    
      
} 
  
class Serialization
{ 
    public static void main(String[] args) 
    {    
    	Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
    	System.out.print("Enter roll number ");  
    	int a= sc.nextInt();  
    	System.out.print("Enter name ");  
    	String b= sc.nextLine();  
    	System.out.print("Enter age ");  
    	int c= sc.nextInt();  
    	System.out.print("Enter address ");  
    	String d= sc.nextLine();  
    	
    	
    	
    	
    	 
        String filename = "file.ser"; 
          
        // Serialization  - Nerwork 1
        try
        {    
            //Saving of object in a file 
            FileOutputStream file = new FileOutputStream(filename); 
            ObjectOutputStream out = new ObjectOutputStream(file); 
              
            
			Object object = null;
			// Method for serialization of object 
            out.writeObject(object); 
              
            out.close(); 
            file.close(); 
              
            System.out.println("Object has been serialized");  
        } 
          
        catch(IOException ex) 
        { 
            System.out.println("None of the field should be blank"); 
        } 
   
        Demo object1 = null; 
  
        // Deserialization  - Network 2
        try
        {    
            // Reading the object from a file 
            FileInputStream file = new FileInputStream(filename); 
            ObjectInputStream in = new ObjectInputStream(file); 
              
            // Method for deserialization of object 
           // object1 = (Demo)in.readObject(); 
              
            in.close(); 
            file.close(); 
              
          
        } 
          
        catch(IOException ex) 
        { 
            System.out.println("IOException is caught"); 
        } 
          
        
  
    } 
} 
