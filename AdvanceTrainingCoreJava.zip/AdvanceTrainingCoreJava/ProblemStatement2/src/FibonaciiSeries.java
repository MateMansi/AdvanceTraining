
public class FibonaciiSeries {
	
	 public static void main(String[] args) {

	        int count = 15, num1 = 1, num2 = 3;
	        System.out.print("Fibonacci Series of "+count+" numbers:");

	        for (int i = 1; i <= count; ++i)
	        {
	            System.out.print(num1+" ");

	            int sumOfPrevTwo = num1 + num2;
	            num1 = num2;
	            num2 = sumOfPrevTwo;
	        }
	    }

}
