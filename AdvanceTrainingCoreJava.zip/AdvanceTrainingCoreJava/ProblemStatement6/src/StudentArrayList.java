

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentArrayList   {
   
	public static void main(String args[]){  
	      ArrayList<String> list=new ArrayList<String>();  
	      list.add("Steve");
	      list.add("Tim");
	      list.add("Lucy");
	      list.add("Pat");
	      list.add("Angela");
	      list.add("Tom");
	  
	      //displaying elements
	      System.out.println(list);
		
	      if (list.contains("Steve"))
	            System.out.println(" Steve exists in the ArrayList");
	  
	        else
	            System.out.println("Steve does not exist in the ArrayList");
	  
	        if (list.contains("nick"))
	            System.out.println("nick exists in the ArrayList");
	  
	        else
	            System.out.println("nick does not exist in the ArrayList");
	        
	    }
	}










	
	





