import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProductManagementDAO {
	
	public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
         try {
      System.out.println("Enter product Id:");
      int productid =sc.nextInt();
      System.out.println("Enter product Name;");
      String name =sc.next();
      System.out.println("Enter product price:");
      int price = sc.nextInt();
      
      Class.forName("mysql.jdbc.Driver");
   Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "username", "passwd");
   PreparedStatement pst = connect.prepareStatement("insert into product(product_id,Product_name,product_price) values(?,?,?)");
 
  pst.setLong(1,productid);
  pst.setString(2, name);
  pst.setLong(3, price);
  
        
  int i = pst.executeUpdate();
  if(i!=0){
        System.out.println("Product Added Successfully");
      }
      else{
        System.out.println("ProductFailed to Add ");
      }
    }
    catch (Exception e){
     System.out.println(e);
    }
  
	Statement mystatement;
	ResultSet output=mystatement.executeQuery("select * from product where productid=\101\"");
	   while(output.next())
	      {
	          System.out.println(output.getString("productid")+"  "+output.getString("name")+"  "+output.getString("price")+" "+output.getString("email"));  
	          
	      }
	      
	           
	    
	
	   Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "username", "passwd");
	         Statement stmt = connect.createStatement();
	       {		      
	         String sql = "DELETE FROM product " +
	            "WHERE productid = 101";
	         stmt.executeUpdate(sql);
	         ResultSet rs = stmt.executeQuery(sql);
	         while(rs.next()){
	            //Display values
	            System.out.print("productId: " + rs.getInt("productid"));
	            System.out.print(",productname: " + rs.getInt("name"));
	            System.out.print(" productprice: " + rs.getString("price"));
	            
	         }
	         
	      } 
	
	       
	      


	       Connection connect1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "username", "passwd");
			         Statement stmt1 = connect1.createStatement();
			       {		      
			         String sql = "UPDATE product " +
			            "SET price = 300 WHERE productid =101";
			         stmt.executeUpdate(sql);
			         ResultSet rs = stmt.executeQuery(sql);
			         while(rs.next()){
			            //Display values
			        	 System.out.print("productId: " + rs.getInt("productid"));
				            System.out.print(",productname: " + rs.getInt("name"));
				            System.out.print(" productprice: " + rs.getString("price"));
			         }
			         rs.close();
			      }
			       catch (Exception e){
			    	     System.out.println(e);
			      } 
			      
			   }

}
