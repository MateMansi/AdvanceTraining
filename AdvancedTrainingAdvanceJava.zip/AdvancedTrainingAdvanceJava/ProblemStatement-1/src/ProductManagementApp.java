
import java.util.*;

public class ProductManagementApp {

	public static void main(String[] args) {
	
		
		List<Product> c =new ArrayList<Product>();
		Scanner sc=new Scanner(System.in);
		Scanner s1=new Scanner(System.in);
		int ch ;
		do {
			System.out.println("1.INSERT");
			System.out.println("2.Display");
			System.out.println("3.SEARCH");
			System.out.println("4.DELETE");
			System.out.println("5.UPDATE");
			System.out.println("0.EXIT");
			System.out.println("Enter The Your Choice :");
			ch=sc.nextInt();
			
			
			
		}while(ch!=0);
	

	}

}
