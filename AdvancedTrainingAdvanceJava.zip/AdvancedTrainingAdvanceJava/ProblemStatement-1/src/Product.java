
public class Product {
	private int Productid;
	private String Productname;
	private int Productprice;
	public int getProductid() {
		return Productid;
	}
	public void setProductid(int productid) {
		Productid = productid;
	}
	public String getProductname() {
		return Productname;
	}
	public void setProductname(String productname) {
		Productname = productname;
	}
	public int getProductprice() {
		return Productprice;
	}
	public void setProductprice(int productprice) {
		Productprice = productprice;
	}

}
